function Eventos = Leer_archivo_eventos(Pac) 


Pnum = num2str(Pac);
Nombre_Mar_Sta = ['Eventos_P' Pnum '.txt'];

fid = fopen(Nombre_Mar_Sta,'rt');
 
oneline = fgets(fid);
oneline = strrep(oneline,'\n','');

i=1;
Eventos = [];

IND = 1;

while ischar(oneline)
    
    if i == 9
        Split_Char = strsplit(oneline,'\t');
        for mm = 1: length(Split_Char)
                Eventos(IND,mm) = str2double(Split_Char(mm));
        end
        IND = IND + 1;
    end
    
    if i == 10
        Split_Char = strsplit(oneline,'\t');
        for mm = 1: length(Split_Char)
                Eventos(IND,mm) = str2double(Split_Char(mm));
        end
    end
   
   
     
    oneline = fgets(fid);
    oneline = strrep(oneline,'\n','');
    i=i+1;
end

end

