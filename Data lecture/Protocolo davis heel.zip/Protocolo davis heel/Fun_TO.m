function porcentaje=Fun_TO( hs1, hs2, to)

long=hs2-hs1;

    y=to-hs1;
    
    x=y*(100)/long;
    
    valor=x;

porcentaje=valor;

end